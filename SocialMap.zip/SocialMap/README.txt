Double click "Run Application.jar" to run the application.

You might have to change the host property in "socialmap.properties" to the IP of the machine where the database is installed.

When something goes wrong (for instance after copying this folder to a different computer), you might have to find the file ".socialMapInit" and delete it.
